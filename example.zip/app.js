// JavaScript Document
Ext.application({
  name: 'Application',
  autoCreateViewport: true,
  controllers: ['ItemController']
});