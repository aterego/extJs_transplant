// JavaScript Document
Ext.define('Ext.mod.model.Analysis',{
	extend:'Ext.data.Model',
	fields:[
		{name:'analysis_id',type:'integer'},
		{name:'name',type:'string'}
	],
});