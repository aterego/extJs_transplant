// JavaScript Document
Ext.define('Ext.mod.model.Donors',{
	extend:'Ext.data.Model',
	fields:[
		{name:'donor_type_id',type:'integer'},
		{name:'name',type:'string'}
	],
});