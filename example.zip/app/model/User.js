// JavaScript Document
Ext.define('Ext.mod.model.User',{
	extend:'Ext.data.Model',
	fields:[
		{name:'user_id',type:'string'},
		{name:'user_name',type:'string'},
		{name:'group_id',type:'string'},
		{name:'group_name',type:'string'}
	],	
});