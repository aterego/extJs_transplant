// JavaScript Document
Ext.define('Ext.mod.model.Medicines',{
	extend:'Ext.data.Model',
	fields:[
		{name:'medicine_id',type:'integer'},
		{name:'name',type:'string'}
	],
});