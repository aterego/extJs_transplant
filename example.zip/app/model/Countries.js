// JavaScript Document
Ext.define('Ext.mod.model.Countries',{
	extend:'Ext.data.Model',
	fields:[
		{name:'country_id',type:'integer'},
		{name:'name',type:'string'}
	],
});