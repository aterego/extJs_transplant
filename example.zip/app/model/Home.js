// JavaScript Document
Ext.define('Ext.mod.model.Home',{
	extend:'Ext.data.Model',
	fields:[
		{name:'name',type:'string'},
		{name:'value',type:'integer'},
		{name:'percent',type:'float'}

	],
});