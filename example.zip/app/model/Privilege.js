// JavaScript Document
Ext.define('Ext.mod.model.Privilege',{
	extend:'Ext.data.Model',
	fields:[
		{name:'privilege_id',type:'string'},
		{name:'privilege',type:'string'},
		{name:'module_id',type:'string'}
	],	
});