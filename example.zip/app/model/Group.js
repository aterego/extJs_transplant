// JavaScript Document
Ext.define('Ext.mod.model.Group',{
	extend:'Ext.data.Model',
	fields:[
		{name:'group_id',type:'string'},
		{name:'group_name',type:'string'},
		{name:'privilege',type:'string'}
	],	
});