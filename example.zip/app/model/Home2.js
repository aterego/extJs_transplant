// JavaScript Document
Ext.define('Ext.mod.model.Home2',{
	extend:'Ext.data.Model',
	fields:[
		{name:'name',type:'string'},
		{name:'value',type:'integer'},
		{name:'percent',type:'float'}

	],
});