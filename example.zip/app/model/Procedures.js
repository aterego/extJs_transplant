// JavaScript Document
Ext.define('Ext.mod.model.Procedures',{
	extend:'Ext.data.Model',
	fields:[
		{name:'procedure_id',type:'integer'},
		{name:'name',type:'string'}
	],
});