// JavaScript Document
Ext.define('Ext.mod.model.Conditions',{
	extend:'Ext.data.Model',
	fields:[
		{name:'condition_id',type:'integer'},
		{name:'condition',type:'string'}
	],
});