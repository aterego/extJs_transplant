// JavaScript Document
Ext.define('Ext.mod.model.Cities',{
	extend:'Ext.data.Model',
	fields:[
		{name:'city_id',type:'integer'},
		{name:'name',type:'string'}
	],
});