// JavaScript Document
Ext.define('Ext.mod.model.Dosage',{
	extend:'Ext.data.Model',
	fields:[
		{name:'dosage_id',type:'integer'},
		{name:'name',type:'string'}
	],
});