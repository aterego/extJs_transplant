// JavaScript Document
Ext.define('Ext.mod.model.Diagnosis',{
	extend:'Ext.data.Model',
	fields:[
		{name:'diagnosis_id',type:'integer'},
		{name:'txt',type:'string'}
	],
});