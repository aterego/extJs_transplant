/**
 * Created by Avetis.Avetisov on 29.06.2016.
 */
// JavaScript Document
Ext.Loader.setConfig({
    enabled: true,
    paths: {
        'Ext.mod': '../../app',
        'Ext.ux': '../../ext/ux'
    }
});


Ext.onReady(function() {


    var storeHome=Ext.create('Ext.mod.store.Home',{
        model: 'Ext.mod.model.Home'
    });

    var storeHome2=Ext.create('Ext.mod.store.Home2',{
        model: 'Ext.mod.model.Home2'
    });

    var total = 0;
    var total2 = 0;

    Ext.define('Ext.chart.theme.ColumnTheme', {
        extend: 'Ext.chart.theme.Base',
        constructor: function(config) {
            this.callParent([Ext.apply({

                colors: ['rgb(17, 95, 166)','rgb(148, 174, 10)','rgb(166, 17, 32)', 'rgb(255, 136, 9)', 'rgb(255, 209, 62)']

            }, config)]);
        }
    });

   var win = Ext.create('Ext.window.Window', {
     //title: 'Home',
     closable: false,
     autoHeight: true,
     autoScroll: true,
        /*
         width: 350,
         height:400,
         */
      showClose :false,
      maximized:true,
      layout:'fit',
      layout: {
            type: 'vbox',
            align : 'stretch',
            pack  : 'start',
      },
      items: [
       {
        xtype: 'chart',
        height: 410,
        id: 'ch1',
        padding: '10 0 0 0',
        style: 'background: #fff',
        animate: true,
        theme:'ColumnTheme',
        shadow: true,
        store: storeHome,
        insetPadding: 40,
        legend: {
            field: 'name',
            position: 'bottom',
            boxStrokeWidth: 0,
            labelFont: '12px Helvetica'
        },
        items: [
            {
            type  : 'text',
            id: 'chText',
            text  : 'აღრიცხვაზე მყოფი პაციენტები, სულ :',
            font  : '22px Helvetica',
            width : 100,
            height: 30,
            x : 40, //the sprite x position
            y : 12  //the sprite y position

        }],
        series: [{
            type: 'pie',
            angleField: 'percent',
            label: {
                field: 'name',
                display: 'outside',
                calloutLine: true,
                renderer: function(v, label, storeItem) {
                    // storeItem is your model, so return the value you want as label
                    return v + " - "  + storeItem.get('value');
                }
            },
            showInLegend: true,
            highlight: {
                segment: {
                    margin: 20
                }
            },
            tips: {
                trackMouse: true,
                renderer: function(storeItem, item) {
                    this.setTitle(storeItem.get('name') + ': ' + storeItem.get('percent') + '%');
                }
            }
        }]
    }
     ,
       {
              xtype: 'chart',
              height: 410,
              id: 'ch2',
              padding: '10 0 0 0',
              style: 'background: #fff',
              animate: true,
              theme:'ColumnTheme',
              shadow: true,
              store: storeHome2,
              insetPadding: 40,
              legend: {
                  field: 'name',
                  position: 'bottom',
                  boxStrokeWidth: 0,
                  labelFont: '12px Helvetica'
              },
              items: [
                  {
                      type  : 'text',
                      id: 'chText2',
                      text  : 'საქართველოში წარმოებული გადანერგვები, სულ :',
                      font  : '22px Helvetica',
                      width : 100,
                      height: 30,
                      x : 40, //the sprite x position
                      y : 12  //the sprite y position

                  }],
              series: [{
                  type: 'pie',
                  angleField: 'percent',
                  label: {
                      field: 'name',
                      display: 'outside',
                      calloutLine: true,
                      renderer: function(v, label, storeItem) {
                          // storeItem is your model, so return the value you want as label
                          return v + " - "  + storeItem.get('value');
                      }
                  },
                  showInLegend: true,
                  highlight: {
                      segment: {
                          margin: 20
                      }
                  },
                  tips: {
                      trackMouse: true,
                      renderer: function(storeItem, item) {
                          this.setTitle(storeItem.get('name') + ': ' + storeItem.get('percent') + '%');
                      }
                  }
              }]
          }
      ]

});


    Ext.onReady(function() {
        win.show();
        storeHome.on('load', function(store, records, successful){
            storeHome.filter([
                {
                    fn   : function(record) {
                        total = total + record.get('value');
                        return record.get('value')
                    },
                    scope: this
                }
            ])

          //Ext.get('chText').setHTML('hello');
           Ext.get('chText').update('<tspan x="40" dy="6.546875">აღრიცხვაზე მყოფი პაციენტები, სულ : ' + total + '</tspan>');

        });

        storeHome2.on('load', function(store, records, successful){
            storeHome2.filter([
                {
                    fn   : function(record) {
                        total2 = total2 + record.get('value');
                        return record.get('value')
                    },
                    scope: this
                }
            ])

            //Ext.get('chText').setHTML('hello');
            Ext.get('chText2').update('<tspan x="40" dy="6.546875">საქართველოში წარმოებული გადანერგვები, სულ : ' + total2 + '</tspan>');

        });


    });


});

