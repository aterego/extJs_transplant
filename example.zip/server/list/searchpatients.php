﻿<?php
/**
 * Developed by AVA - A.Avetisov.
 * Date: 15.07.2016
 */
ob_start();
header("Content-Type: application/json");
include("../inc/connection.php");
include("../inc/function.php");

$limit = 3000; //$_POST['limit']; //the pagesize
$start = 0;// $_POST['start']; //Offset



date_default_timezone_set('Asia/Tbilisi');

$act="";
$response=array();
$temp_record=array();
if(isset($_GET['act'])){
	if(!empty($_GET['act'])){
		$act=$_GET['act'];
	}else{
		//respon error
		$response=array('success'=>false,'data'=>false);
	}
}else{
	//respon error
	$response=array('success'=>false,'data'=>false);
}

if(!empty($act)){
	$mod="tab-group_";
	switch($act){
		case "View":

			$whereclause = "";
			$whereclause2 = "";
			if(isset($_GET['catvalues']) && !empty($_GET['catvalues'])) {
				$pieces = explode(",", $_GET['catvalues']);
				if (count($pieces) > 0) {
					for ($i = 0; $i < count($pieces); $i++) {
						if ($i == 0)
							$whereclause = " WHERE pc.category_id in (" . $pieces[0];
						else
							$whereclause = $whereclause . "," . $pieces[$i];

						if ($i == (count($pieces) - 1))
							$whereclause = $whereclause . ")";
					}
				}
			}

			if(!empty($whereclause)) {
				$whereclause2 = " where j.m<>57 and j.m<>58 and j.m<>59 and j.m<>60 and j.m<>68";
				$arcArr = array(57, 58, 59, 60, 68);
				if (isset($_GET['archvalues']) && !empty($_GET['archvalues'])) {
					$pieces = explode(",", $_GET['archvalues']);
					//***AVA*** remove cats from array
					$newArray = array_merge(array_diff($arcArr, $pieces));
					if (count($newArray) > 0) {
						for ($i = 0; $i < count($newArray); $i++) {
							if ($i == 0)
								$whereclause2 = " where j.m<>" . $newArray[0];
							else
								$whereclause2 = $whereclause2 . " and j.m<>" . $newArray[$i];
						}
					}

				}
			}
			else{
				if(isset($_GET['archvalues']) && !empty($_GET['archvalues'])) {
					$pieces = explode(",", $_GET['archvalues']);
					if (count($pieces) > 0) {
						for ($i = 0; $i < count($pieces); $i++) {
							if ($i == 0)
								$whereclause = " WHERE pc.category_id in (" . $pieces[0];
							else
								$whereclause = $whereclause . "," . $pieces[$i];

							if ($i == (count($pieces) - 1))
								$whereclause = $whereclause . ")";
						}
					}
				}

			}

			if (!empty($_GET['cpatient']))
				if(!empty($whereclause))
					$whereclause = $whereclause. " and p.patient_id=".$_GET['cpatient'];
				else
					$whereclause = " where p.patient_id=".$_GET['cpatient'];

			if (!empty($_GET['ccountry']))
			 if(!empty($whereclause))
				$whereclause = $whereclause. " and p.country_id=".$_GET['ccountry'];
			 else
			    $whereclause = " where p.country_id=".$_GET['ccountry'];

			if (!empty($_GET['ccity']))
				if(!empty($whereclause))
					$whereclause = $whereclause. " and p.city_id=".$_GET['ccity'];
				else
					$whereclause = " where p.city_id=".$_GET['ccity'];

			if (!empty($_GET['cclinic']))
				if(!empty($whereclause))
					$whereclause = $whereclause. " and t.clinic_id=".$_GET['cclinic'];
				else
					$whereclause = " where t.clinic_id=".$_GET['cclinic'];

			if (!empty($_GET['cdoctor']))
				if(!empty($whereclause))
					$whereclause = $whereclause. " and t.doctor_id=".$_GET['cdoctor'];
				else
					$whereclause = " where t.doctor_id=".$_GET['cdoctor'];

			if (!empty($_GET['cdiagnosis']))
				if(!empty($whereclause))
					$whereclause = $whereclause. " and t.diagnosis_id=".$_GET['cdiagnosis'];
				else
					$whereclause = " where t.diagnosis_id=".$_GET['cdiagnosis'];

			if (!empty($_GET['cdonor']))
				if(!empty($whereclause))
					$whereclause = $whereclause. " and t.donor_type_id=".$_GET['cdonor'];
				else
					$whereclause = " where t.donor_type_id=".$_GET['cdonor'];

			if (!empty($_GET['cmeds'])) {

				$meds = explode(",", $_GET['cmeds']);
				if (count($meds) > 0) {

					if (!empty($_GET['cmedC'])) {

						if ($_GET['cmedC'] == 2) {
							for ($i = 0; $i < count($meds); $i++) {
								if ($i == 0) {
									if (!empty($whereclause))
										$whereclause = $whereclause . " and m.medicine_id in (" . $meds[0];
									else
										$whereclause = " where m.medicine_id in (" . $meds[0];
								} else
									$whereclause = $whereclause . "," . $meds[$i];

								if ($i == (count($meds) - 1))
									$whereclause = $whereclause . ")";
							}
						} else {

							//$tempclause = $whereclause;

							for ($i = 0; $i < count($meds); $i++) {
								if ($i != 0)
								 $whereclause = $whereclause . " left join a_treatment_medicines m".($i +1)." on (t.patient_id = m".($i +1).".patient_id)  ";
							}
							//$whereclause = $whereclause.$tempclause;


							for ($i = 0; $i < count($meds); $i++) {
								if ($i == 0) {
									if (!empty($tempclause))
										$whereclause = $whereclause . " and m.medicine_id =" . $meds[0];
									else
										$whereclause = $whereclause . " where m.medicine_id =" . $meds[0];
								}
								else
									$whereclause = $whereclause . " and m".($i +1).".medicine_id =" . $meds[$i];

							}


						}

					}

				} else {
					if (!empty($whereclause))
						$whereclause = $whereclause . " and m.medicine_id =" . $_GET['cmeds'];
					else
						$whereclause = " where m.medicine_id in =" . $_GET['cmeds'];
				}

			}



			if (!empty($_GET['cdate1'])) {

				$d1 = DateTime::createFromFormat('m/d/Y/H:i:s', $_GET['cdate1']."/11:00:00");
				$date1 = $d1->getTimestamp();

				if(!empty($whereclause))
					$whereclause = $whereclause. " and t.date >=".$date1;
				else
					$whereclause = " where t.date >= ".$date1;
			}

			if (!empty($_GET['cdate2'])) {

				$d2 = DateTime::createFromFormat('m/d/Y/H:i:s', $_GET['cdate2']."/11:00:00");
				$date2 = $d2->getTimestamp();

				if(!empty($whereclause))
					$whereclause = $whereclause. " and t.date <=".$date2;
				else
					$whereclause = " where t.date <= ".$date2;
			}


			if (!empty($_GET['sw'])){

				$sw = urldecode($_GET['sw']);

				if(!empty($whereclause))
					$whereclause = $whereclause. " and ";
				else
					$whereclause = " where ";

					$whereclause .= "  p.patientname like '%".$sw."%' or
					                   p.patientlastname like '%".$sw."%' or
	                                   p.phone2 like '%".$sw."%' or
	                                   cnt.name like '%".$sw."%' or 
	                                   cts.name like '%".$sw."%' or 
                                       p.personalid like '%".$sw."%' or
					                   p.history_id like '%".$sw."%' or
					                   p.phone1 like '%".$sw."%' or
					                   p.email like '%".$sw."%' or
					                   p.address1 like '%".$sw."%' or
					                   p.address2 like '%".$sw."%' or
					                   p.work_phone like '%".$sw."%' or
					                   p.work like '%".$sw."%' or	 
					                   cln.clinicdesc like '%".$sw."%' or
					                   don.name like '%".$sw."%' or
					                   doc.doctorname like '%".$sw."%' or
					                   doc.doctorlastname like '%".$sw."%' or
					                   op.doctorname like '%".$sw."%' or
					                   op.doctorlastname like '%".$sw."%' or
					                   di.txt like '%".$sw."%' or
					                   inf.info like '%".$sw."%' 
					                   ";
             }

            /*
			// count the Data
			$result = $mysqli->query("
                     SELECT COUNT(*) AS count FROM(
                       SELECT p.patient_id,  max(pc.`category_id`) as m
                            from `a_patient` p
                            left join a_patient_category pc on pc.patient_id = p.patient_id
                            inner join a_transplantations t on t.patient_id = p.patient_id
                            ".$whereclause."  group by p.patient_id, t.reg_id
                        ) AS j 
                        ".$whereclause2);



			$row =  $result->fetch_assoc();//
			$count = $row['count'];

			*/

			$query= $mysqli->query("
               select  j.*
                     from
                      (
                            select p.*, cnt.name as country_name, cts.name as city_name,t.reg_id, t.`date`,t.donor_type_id, t.donor_info, t.clinic_id,t.operator_id,t.doctor_id,t.diagnosis_id, am.name as medicine,
                              cln.clinicdesc as clinic, doc.doctorname as docname, doc.doctorlastname as doclastname, op.doctorname as opname, op.doctorlastname as oplastname, don.name as donor, di.txt as diagnosis,
                              inf.blood_type_id,inf.rhesus, inf.info, max(pc.`category_id`) as m

                            from `a_patient` p
                            left join a_countries cnt on  cnt.country_id=p.country_id
                            left join a_cities cts on cts.city_id=p.city_id
                            left join a_patient_category pc on pc.patient_id = p.patient_id
                            inner join a_transplantations t on t.patient_id = p.patient_id
                            left join a_treatment_medicines m on (t.patient_id = m.patient_id) 
                            left join a_diagnosis di on di.diagnosis_id=t.diagnosis_id
                            left join a_medicines am on am.medicine_id=m.medicine_id
                            left join a_clinic cln on cln.clinic_id = t.clinic_id
                            left join a_doctor doc on doc.doctor_id=t.doctor_id
                            left join a_doctor op on op.doctor_id=t.operator_id
                            left join a_donor_types don on don.donor_type_id=t.donor_type_id
                            left join a_patient_info inf on inf.patient_id=p.patient_id
                            ".$whereclause." group by patient_id, t.reg_id 
                      ) as j 
                          ".$whereclause2."    LIMIT $start, $limit");




			if($query){
				while($r = $query->fetch_array()){

					/*
					$query2 = $mysqli->query("SELECT image FROM a_patient_photo WHERE `patient_id`= ". $r['patient_id']);
					if($query2){
						$r2 = $query2->fetch_array();
						$pimage = $r2['image'];
					}
					*/

					$query2 = $mysqli->query("SELECT o.* , c.condition as con
                       FROM `a_patient_history` o   
                        LEFT JOIN `a_patient_history` b            
                         ON o.`patient_id` = b.`patient_id` AND o.`date` < b.`date` 
                        INNER JOIN `a_patient_condition` c 
                         ON c.condition_id=o.condition_id
                        WHERE b.`date` is NULL and o.`patient_id`=" .$r['patient_id']." and o.`reg_id`=".$r['reg_id']);
					if($query2){
						$r2 = $query2->fetch_array();
						$con_date = (abs($r2['date'])< 1000)? "-" : date('d.m.Y', $r2['date']);
						$condition = $r2['con'];
					}
					else {
						$con_date = "-";
						$condition = "-";
					}

					$temp_record[]=array(
						"patient_id"=>$r['patient_id'],
						"reg_id"=>$r['reg_id'],
						"patientlastname"=>$r['patientlastname'],
						"patientname"=>$r['patientname'],
						"birthday"=>(abs($r['birthday'])< 1000)? "-" : date('d.m.Y', $r['birthday']),
						"phone2"=>$r['phone2'],
						"patronymic"=>$r['patronymic'],
						"country_id"=>$r['country_id'],
						"country_name"=>$r['country_name'],
						"city_id"=>$r['city_id'],
						"city_name"=>$r['city_name'],
						"personalid"=>$r['personalid'],
						"history_id"=>$r['history_id'],
						"gendercode"=>$r['gendercode'],
						"gender"=>($r['gendercode']==1)?"მამრობითი":"მდედრობითი",
						"phone1"=>$r['phone1'],
						"email"=>$r['email'],
						"address1"=>$r['address1'],
						"address2"=>$r['address2'],
						"work_phone"=>$r['work_phone'],
						"work"=>$r['work'],
						"editorcode"=>$r['editorcode'],
						"transdate"=>(abs($r['date'])< 1000)? "-" : date('d.m.Y', $r['date']),
						"clinic_id"=>$r['clinic_id'],
						"clinic"=>$r['clinic'],
						"donor_type_id"=>$r['donor_type_id'],
						"donor"=>$r['donor'],
						"doctor_id"=>$r['doctor_id'],
						"operator_id"=>$r['operator_id'],
						"docname"=>$r['docname'],
						"doclastname"=>$r['doclastname'],
						"opname"=>$r['opname'],
						"oplastname"=>$r['oplastname'],
						"diagnosis_id"=>$r['diagnosis_id'],
						"diagnosis"=>$r['diagnosis'],
						"medicine_id"=>$r['medicine_id'],
						"medicine"=>$r['medicine'],
						"con_date"=>$con_date,
						"condition"=>$condition,
						"blood_type_id"=>$r['blood_type_id'],
						"rhesus"=>$r['rhesus'],
						"info"=>$r['info'],
						//"pimage"=> base64_encode($pimage)

					);

				}
				//$r2->free();
				//$response=array('items'=>$temp_record, 'totalCount' => $count);
				$response=array('items'=>$temp_record);
				//$response=$temp_record;
				//array_push($response,array('totalCount' => 1421));

			}
			break;


	}
}else{
	$response=array('success'=>false,'data'=>false);
}
echo  json_encode($response);
?>