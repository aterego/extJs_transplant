﻿<?php
ob_start();
header("Content-Type: application/json");
include("../inc/connection.php");
include("../inc/function.php");

$limit = $_POST['limit']; //the pagesize
$start = $_POST['start']; //Offset

date_default_timezone_set('Asia/Tbilisi');

$act="";
$response=array();
$temp_record=array();
if(isset($_GET['act'])){
	if(!empty($_GET['act'])){
		$act=$_GET['act'];	
	}else{
		//respon error
		$response=array('success'=>false,'data'=>false);	
	}
}else{
	//respon error
	$response=array('success'=>false,'data'=>false);	
}

if(!empty($act)){
	$mod="tab-group_";
	switch($act){
		case "View":


			// count the Data Liv
			$result = $mysqli->query("SELECT COUNT(*) AS count FROM 
                       `a_transplantations` o   
                       LEFT JOIN `a_clinic` c ON c.`clinic_id` = o.`clinic_id`
                       INNER JOIN `a_patient_category` ca ON ca.patient_id=o.`patient_id`
                       WHERE  c.`country_id`=4302  AND ca.`category_id` in (43)");

			$row =  $result->fetch_assoc();//
			$liv = $row['count'];

			// count the Data Htx
			$result = $mysqli->query("SELECT COUNT(*) AS count FROM 
                       `a_transplantations` o   
                       LEFT JOIN `a_clinic` c ON c.`clinic_id` = o.`clinic_id`
                       INNER JOIN `a_patient_category` ca ON ca.patient_id=o.`patient_id`
                       WHERE  c.`country_id`=4302  AND ca.`category_id` in (65)");

			$row =  $result->fetch_assoc();//
			$htx = $row['count'];

			// count the Data Kd
			$result = $mysqli->query("SELECT COUNT(*) AS count FROM 
                       `a_transplantations` o   
                       LEFT JOIN `a_clinic` c ON c.`clinic_id` = o.`clinic_id`
                       INNER JOIN `a_patient_category` ca ON ca.patient_id=o.`patient_id`
                       WHERE  c.`country_id`=4302  AND ca.`category_id` in (44)");

			$row =  $result->fetch_assoc();//
			$kd = $row['count'];

			   $total = $liv + $htx + $kd;

			  $temp_record[0] = array(
				"name" => "LivTx ღვიძლი",
				"value" => $liv,
				"percent" =>	number_format( $liv/$total * 100, 2 )
			  );
			   $temp_record[1] = array(
				 "name" => "KdTx თირკმელი",
				 "value" => $kd,
				 "percent" =>	number_format( $kd/$total * 100, 2 )
			   );

			    $temp_record[2] = array(
				  "name" => "HTx გული",
				  "value" => $htx,
				  "percent" =>	number_format( $htx/$total * 100, 2 )
			    );

				//$r2->free();
				$response=array('items'=>$temp_record);
				//$response=$temp_record;
                //array_push($response,array('totalCount' => 1421));

		break;
	   }


}else{
	$response=array('success'=>false,'data'=>false);	
}
echo  json_encode($response);
?>