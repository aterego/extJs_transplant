<?php
/**
 * Developed by AVA - A.Avetisov.
 * Date: 15.07.2016
 */
ob_start();
header("Content-Type: application/json");
include("../inc/connection.php");
include("../inc/function.php");
$act="";
$response=array();
$temp_record=array();

date_default_timezone_set('Asia/Tbilisi');

if(isset($_GET['act'])){
	if(!empty($_GET['act'])){
		$act=$_GET['act'];
	}else{
		//respon error
		$response=array('success'=>false,'data'=>false);	
	}
}else{
	//respon error
	$response=array('success'=>false,'data'=>false);	
}

if(!empty($act)){
	$mod="tab-categories_";
	switch($act){
		case "View":
			$query= $mysqli->query("SELECT * FROM `categories` c inner join a_patient_category as ac on ac.category_id= c.`category_id` WHERE ac.patient_id=".$_POST['param_id']);
			if($query){
				$c = 0;
				while($r = $query->fetch_array()){
					$temp_record[]=array(
						"category_id"=>$r['category_id'],
						"reg_id"=>$r['reg_id'],
						"parent_category_id"=>$r['parent_category_id'],
						"category_name"=>$r['category_name'],
						"prefix"=>$r['prefix'],
						"patient_id"=>$r['patient_id'],
						"date"=>(abs($r['date'])< 1000)? "-" : date('d.m.Y', $r['date']),
					);
				}
				$response=$temp_record;
			}
		break;
		
		case "Add":

			$d = DateTime::createFromFormat('m/d/Y/H:i:s', date("m/d/Y")."/11:00:00", new DateTimeZone('Asia/Tbilisi'));
			$date = $d->getTimestamp();

			$query= $mysqli->query("insert into a_patient_category (`patient_id`,`category_id`, `date`) 
               values(".$_POST['patient_id'].",".$_POST['category_id']."," .$date. ")");
			if($query){
				$response = array( 'success'=>true, 'data'=>true );	
			}else{
				$response=array('success'=>false,'data'=>false);
			}
		break;
		
		case "Update":
			$query=mysql_query("update tb_group set group_name='".$_POST[$mod.'txtEditGroupName']."' where group_id='".$_POST['param_id']."'");
			if($query){
				$response = array( 'success'=>true, 'data'=>true );
			}else{
				$response=array('success'=>false,'data'=>false);
			}
		break;
		
		case "Delete":
			$query=$mysqli->query("delete from a_patient_category where patient_id=".$_POST['param_id']." and reg_id=".$_POST['reg_id']);
			if($query){
				$response = array( 'success'=>true, 'data'=>true );
			}else{
				$response=array('success'=>false,'data'=>false);
			}
		break;
		
		case "AddModule":
			$query=mysql_query("Update tb_group set privilege='".$_POST['param_module']."' where group_id='".$_POST['param_id']."'")or die (mysql_error());
			if($query){
				$response = array( 'success'=>true, 'data'=>true );
			}else{
				$response=array('success'=>false,'data'=>false);
			}
		break;
	}
}else{
	$response=array('success'=>false,'data'=>false);	
}
echo  json_encode($response);
?>